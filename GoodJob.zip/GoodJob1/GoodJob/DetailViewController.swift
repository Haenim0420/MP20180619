//
//  DetailViewController.swift
//  GoodJob
//
//  Created by SWUCOMPUTER on 2018. 6. 19..
//  Copyright © 2018년 SWUCOMPUTER. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController {

    @IBOutlet var addDueDate: UILabel!
    
    @IBOutlet var textName: UITextField!
    @IBOutlet var textDuty: UITextField!
    @IBOutlet var textTerm: UITextField!
    
    @IBOutlet var saveData: UILabel!
    @IBOutlet var textMemo: UILabel!
    var detailMain: NSManagedObject?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let main = detailMain {
            textName.text = main.value(forKey: "cName") as? String
            textDuty.text = main.value(forKey: "duty") as? String
            textMemo.text = main.value(forKey: "memo") as? String
            
        //    let dbDate: Date? = main.value(forKey: "saveDate") as? Date
            
        //    let formatter: DateFormatter = DateFormatter()
         //   formatter.dateFormat = "yyyy-MM-dd h:mm a"
         //   if let unwrapDate = dbDate {
          //      let displayDate = formatter.string(from: unwrapDate as Date)
         //       saveData.text = displayDate
         //   }
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
