//
//  InsertViewController.swift
//  GoodJob
//
//  Created by SWUCOMPUTER on 2018. 6. 19..
//  Copyright © 2018년 SWUCOMPUTER. All rights reserved.
//

import UIKit
import CoreData

class InsertViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var textName: UITextField!
    @IBOutlet var pickDate: UIDatePicker!
    @IBOutlet var textDuty: UITextField!
    @IBOutlet var textTerm: UITextField!
    @IBOutlet var addWhat: UISegmentedControl!
    @IBOutlet var addMemo: UITextView!
    
    func getContext () -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    @IBAction func savePressed(_ sender: Any) {
        let context = getContext()
        let entity = NSEntityDescription.entity(forEntityName: "Main", in: context)
        
        let object = NSManagedObject(entity: entity!, insertInto: context)
        
        object.setValue(textName.text, forKey: "cName")
        object.setValue(textDuty.text, forKey: "duty")
        object.setValue(textTerm.text, forKey: "term")
        object.setValue(addMemo.text, forKey: "memo")
        
        
        
        
        do {
            try context.save()
            print("saved!")
        }
            
            
        catch let error as NSError {
            print("Could not save  (error),  (error.userInfo)")
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
